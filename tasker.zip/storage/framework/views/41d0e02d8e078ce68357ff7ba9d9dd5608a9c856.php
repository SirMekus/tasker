<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['header']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['header']); ?>
<?php foreach (array_filter((['header']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="navbar-collapse">
    <?php if(!empty(url()->previous())): ?>
    <a href="<?php echo e(url()->previous()); ?>" class="text-decoration-none text-dark">
            <i class="fas fa-arrow-left fa-lg"></i>
        </a>
        <?php endif; ?>
<span class='ms-2 fs-5 fw-bold'><?php echo e($header); ?></h3>
    </div><?php /**PATH C:\xampp\htdocs\tasker\resources\views/components/page-header.blade.php ENDPATH**/ ?>