<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <title><?php echo e($title ?? config('app.name')); ?></title>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.meta-head','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('meta-head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</head>

<body class='bg-white'>

    <div class="container-fluid">
        <div class="row flex-nowrap">
            <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark">
                <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100 sticky-top">
                    <a class="navbar-brand d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none" href="<?php echo e(route('home')); ?>">
                        <img src="<?php echo e(asset('storage/for_site/heart.png')); ?>" alt="" srcset="" width="64px" height="64px">
                    </a>
                    <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                        <li class="nav-item">
                            <a href="<?php echo e(route('tasks')); ?>" class="nav-link font-weight-bold text-light align-middle px-0">
                                <i class="fs-4 fas fa-house-user"></i> <span class="ms-1 d-none d-sm-inline fw-bold">Tasks</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('projects')); ?>" class="nav-link font-weight-bold text-light align-middle px-0">
                                <i class="fs-4 fas fa-chalkboard"></i> <span class="ms-1 d-none d-sm-inline fw-bold">Projects</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link font-weight-bold text-light align-middle px-0 pre-run" data-caption="Are you sure you want to logout?"
                                data-classname="logout-form" data-bc="admin_logout"
                                href="<?php echo e(route('logout')); ?>">
                                <i class="fas fa-sign-out-alt"></i><span class="ms-1 d-none d-sm-inline">Log Out</span></a>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="col">
                <nav class="nav navbar navbar-expand nav-fill justify-content-center home-color sticky-top fixed-top"
                    role="navigation">

                    <div class="d-flex justify-content-center w-75">
                        <div
                            class="text-center text-truncate text-light fw-bold fs-1 fst-italic font-monospace shadow-sm">
                            <?php echo e(config('app.name')); ?>

                        </div>
                    </div>
                </nav>

                <?php echo e($slot); ?>


            </div>

        </div>
    </div>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\tasker\resources\views/components/layout/master.blade.php ENDPATH**/ ?>