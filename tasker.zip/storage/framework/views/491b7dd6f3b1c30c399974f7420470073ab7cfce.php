<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.master','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="card">
        <div class="rounded-0 card-body">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['header' => 'Projects']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'Projects']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <form class="form-inline row" method="get" action="<?php echo e(url()->current()); ?>" role="search">
                <div class="col-4 my-1">
                    <label>Date Created</label>
                    <input type="date" value="<?php echo e(request()->date); ?>" name="date" class="form-control input-lg" />
                </div>

                <?php if(request()->filled('user_id')): ?>
                <input type="hidden" value="<?php echo e(request()->user_id); ?>" name="user_id" />
                <?php endif; ?>

                <div class="col-4 my-1 mt-2">
                    <button type="submit" class="btn home-color text-white btn-sm mt-4">Search</button>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-stripped table-bordered">
                    <thead>
                        <tr class="sticky-top">
                            <th>S/N</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Deadline</th>
                            <th>Date Created</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
                        $sn = 0;
                        ?>

                        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                        $sn +=1;
                        ?>

                        <tr>

                            <td><?php echo e($sn); ?></td>

                            <td><?php echo e($activity->name); ?></td>

                            <td><?php echo e($activity->description); ?></td>

                            <td><?php echo e(carbon($activity->deadline)->format('l jS \\of F Y')); ?></td>

                            <td><?php echo e($activity->created_at->toDayDateTimeString()); ?></td>

                            <td>
                                <a class="text-decoration-none btn btn-sm bg-dark text-white" href="<?php echo e(route('tasks', ['project'=>$activity->id])); ?>">Tasks</a>
                            </td>

                            <td>
                                <a class="text-decoration-none btn btn-sm bg-warning open-as-modal" href="<?php echo e(route('project.form', ['id'=>$activity->id, 'user_id'=>request()->user_id])); ?>"><i
                                class="fa fa-edit text-white fa-fw"></i></a>
                            </td>
                            
                            <td>
                                <a class="text-decoration-none btn btn-sm bg-danger pre-run" data-caption="Are you sure you want to delete this project?" href="<?php echo e(route('project.delete', ['id'=>$activity->id])); ?>"><i
                                    class="fa fa-trash text-white fa-fw"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php echo e($activities->links()); ?>


            <div class="d-flex justify-content-center">
                <a class="text-decoration-none text-white btn btn-lg bg-dark open-as-modal" href="<?php echo e(route('project.form', ['date'=>$date, 'user_id'=>request()->user_id])); ?>">
                    <span>Create Project</span>
                </a>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\tasker\resources\views/projects.blade.php ENDPATH**/ ?>