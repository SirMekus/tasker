<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.master','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="card">
        <div class="rounded-0 card-body">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['header' => 'Activities']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'Activities']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <form class="form-inline row" method="get" action="<?php echo e(url()->current()); ?>" role="search">
                <div class="col-4 my-1">
                    <label>Date</label>
                    <input type="date" value="<?php echo e($date); ?>" name="date" class="form-control input-lg" />
                </div>

                <?php if(request()->filled('user_id')): ?>
                <input type="hidden" value="<?php echo e(request()->user_id); ?>" name="user_id" />
                <?php endif; ?>

                <div class="col-4 my-1 mt-2">
                    <button type="submit" class="btn home-color text-white btn-sm mt-4">Search</button>
                </div>
            </form>

            <?php if(request()->user('admin') and request()->user('admin')->isSuperAdmin()): ?>
            <div class="d-flex justify-content-center">
                <a href="#" class="text-decoration-none bg-dark text-light btn" data-bs-toggle="modal" data-bs-target="#calendarModal">
                    <span class="text-center fs-1 fw-bolder"><?php echo e(carbon($date)->format('jS')); ?></span><br />
                    <span class="fw-bold"><?php echo e(carbon($date)->format('F, Y')); ?></span>
                </a>
            </div>

            <div class="modal fade" id="calendarModal" tabindex="-1" aria-labelledby="calendarModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-fullscreen">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <?php echo $calendar->show($date); ?>

                    </div>
                    <div class="modal-footer">
                        <a href='<?php echo e(url()->current()); ?>' class='btn float-end text-primary'>Today</a>
                    </div>
                  </div>
                </div>
            </div>
            <?php endif; ?>
            <hr/>

            <div class="table-responsive">
                <table class="table table-stripped table-bordered">
                    <thead>
                        <tr class="sticky-top">
                            <th>S/N</th>
                            <th>Image</th>
                            <th>Title</th>
                            <th>Intended For</th>
                            <th>Description</th>
                            <th>Date Created</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
                        $sn = 0;
                        ?>

                        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                        $sn +=1;
                        ?>

                        <tr>
                            <td><?php echo e($sn); ?></td>

                            <td><img class="img-thumbnail" width="60" data-src="<?php echo e(asset('storage/activities/'.$activity->image)); ?>" /></td>

                            <td><?php echo e(activityToDisplay($activity)->title); ?></td>

                            <?php if(!empty(activityToDisplay($activity)->user)): ?>
                            <td>
                                <?php if(request()->user('admin')): ?>
                                <a class="text-decoration-none" href="<?php echo e(route('users', ['id'=>activityToDisplay($activity)->user->id])); ?>">
                                <?php echo e(activityToDisplay($activity)->user->name['firstname']); ?> <?php echo e(activityToDisplay($activity)->user->name['lastname']); ?></a>
                                <?php else: ?>
                                <?php echo e(activityToDisplay($activity)->user->name['firstname']); ?> <?php echo e(activityToDisplay($activity)->user->name['lastname']); ?>

                                <?php endif; ?>
                            </td>
                            <?php else: ?>
                            <td><span class='badge badge-pill bg-dark'>General</span></td>
                            <?php endif; ?>

                            <td><?php echo e(activityToDisplay($activity)->description); ?></td>

                            <td><?php echo e($activity->created_at->toDayDateTimeString()); ?></td>

                            <?php if(request()->user('admin') and request()->user('admin')->isSuperAdmin()): ?>
                            <td>
                                <a class="text-decoration-none btn btn-sm bg-warning open-as-modal" href="<?php echo e(route('activity.form', ['id'=>$activity->id, 'user_id'=>request()->user_id])); ?>"><i
                                class="fa fa-edit text-white fa-fw"></i></a>
                            </td>

                            <td>
                                <a class="text-decoration-none btn btn-sm bg-danger pre-run" data-caption="Are you sure you want to delete this activity?" href="<?php echo e(route('activity.delete', ['id'=>$activity->id])); ?>"><i
                                    class="fa fa-trash text-white fa-fw"></i></a>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php echo e($activities->links()); ?>


            <?php if(request()->user('admin') and request()->user('admin')->isSuperAdmin()): ?>
            <?php if($activities->count() < 4): ?>
            <div class="d-flex justify-content-center">
                    <a class="text-decoration-none text-white btn btn-lg bg-dark open-as-modal" href="<?php echo e(route('activity.form', ['date'=>$date, 'user_id'=>request()->user_id])); ?>">
                        <span>Create Activity</span>
                    </a>
            </div>
            <?php endif; ?>

            <div class="fixed-bottom">
                <a class="float-end" href="#" data-bs-toggle="modal" data-bs-target="#calendarModal"><i class="fa-3x fas fa-calendar-alt bg-white text-dark"></i></a>
            </div>
            <?php endif; ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\todo\resources\views/activities.blade.php ENDPATH**/ ?>