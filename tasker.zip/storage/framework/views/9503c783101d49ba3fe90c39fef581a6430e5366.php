<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.master','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row justify-content-center">
    <div class="col-md-12">
        <div class="card">

            <div class="card-body">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['header' => ''.e(!empty($admin) ? 'Update Admin': 'Create Admin').'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => ''.e(!empty($admin) ? 'Update Admin': 'Create Admin').'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                <hr/>
                <form action="<?php echo e(route('admin.create.post')); ?>" id="form" method="post">
                    <div class="row mt-3">
                        <div class="col-6">
                            <label>First Name<span style="color:red;">*</span></label>
                            <input type="text" class="form-control form-control-lg borderless-input" autocomplete
                                value="<?php echo e(!empty($admin) ? $admin->name['firstname'] : null); ?>" name="firstname" />
                        </div>

                        <div class="col-6">
                            <label>Last Name<span style="color:red;">*</span></label>
                            <input type="text" class="form-control form-control-lg borderless-input" autocomplete
                                value="<?php echo e(!empty($admin) ? $admin->name['lastname'] : null); ?>" name="lastname" />
                        </div>
                    </div>

                    <div class="row mt-2 ">
                        <div class="col-12">
                            <label>Role<span style="color:red;">*</span></label>
                            <select class="form-control form-control-lg" required="required" name="role">
                                <option <?php echo e((!empty($admin) and ($admin->role == "super_admin")) ? 'selected' : null); ?> value="super_admin">Super Admin</option>
                                <option <?php echo e((!empty($admin) and ($admin->role == "regular")) ? 'selected' : null); ?> value="regular">Regular Admin</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-lg-6 col-xs-12">
                            <label>Email<span style="color:red;">*</span></label>
                            <input type="email" class="form-control form-control-lg borderless-input" autocomplete
                                value="<?php echo e(!empty($admin) ? $admin->email : null); ?>" name="email" />
                        </div>

                        <div class="col-lg-6 col-xs-12">
                            <label>Create Password<span style="color:red;">*</span></label>
                            <div class="input-group form-group input-lg mb-3">
                                <input type="password"
                                    class="form-control form-control-lg signup-field borderless-input"
                                    placeholder="password" id="password" name="password" v-model="state.form.password">
                                <div class="bg-dark input-group-text">
                                    <a class="text-light password-visibility" data-id='password' href="#">
                                        <i class="fas fa-eye-slash "></i>
                                    </a>
                                </div>
                                <div class="bg-dark input-group-text">
                                    <button data-strength="decent_pw" data-target="password"
                                        class="text-light btn btn-sm gen-password">
                                        <i class="fas fa-key"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if(!empty($admin)): ?>
                    <input type="hidden" value="<?php echo e($admin->id); ?>" name="id" />
                    <?php endif; ?>

                    <div class="form-group mt-3">
                        <input class="btn home-color text-white btn-lg w-100" type="submit" value="<?php echo e(!empty($admin) ? " Update Admin": "Create Admin"); ?>" />
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\todo\resources\views/admin/create-admin.blade.php ENDPATH**/ ?>