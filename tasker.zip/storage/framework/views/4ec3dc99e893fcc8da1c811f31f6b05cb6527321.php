<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.master','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class='card'>
        <div class='card-body'>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['header' => 'Users']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'Users']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <form class="form-inline row" method="get" action="<?php echo e(url()->current()); ?>" role="search">
                    <div class="col-4 my-1">
                        <label>Search</label>
                        <input type="text" value="<?php echo e(request()->search); ?>" name="search" class="form-control input-lg" placeholder="search for..." />
                    </div>

                    <div class="col-4 my-1 mt-2">
                        <button type="submit" class="btn home-color text-white btn-sm mt-4">Search</button>
                    </div>
                </form>

            <div class='table-responsive'>
            <table class="table table-stripped table-bordered">
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Date Created</th>
                    </tr>
                </thead>
                <tbody>

                    <?php
                    $i = 0;
                    $offset = ($result->currentPage() - 1) * $result->perPage();
                    ?>

                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php
                    $i +=1;
                    $sn = $offset + $i;
                    ?>

                    <tr>
                        <td><?php echo e($sn); ?></td>
                        
                        <td><?php echo e($user->name['firstname']); ?> <?php echo e($user->name['lastname']); ?></td>

                        <td><?php echo e($user->email); ?></td>

                        <td><?php echo e($user->created_at->toDayDateTimeString()); ?></td>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isOga', request()->user('admin'))): ?>
                        <td>
                            <a class="text-decoration-none btn btn-sm btn-info open-as-modal" href="<?php echo e(route('activity.form', ['user_id'=>$user->id])); ?>">Create Activity</a>
                        </td>
                        <?php endif; ?>

                        <td>
                            <a class="text-decoration-none btn btn-sm btn-primary" href="<?php echo e(route('activities', ['user_id'=>$user->id])); ?>">Activities</a>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
            <hr />

            <?php echo e($result->links()); ?>



            <h3>Total: <?php echo e($result->total()); ?></h3>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\todo\resources\views/admin/users.blade.php ENDPATH**/ ?>