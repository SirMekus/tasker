<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.master','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class='card'>
        <div class='card-body'>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['header' => 'Admins']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'Admins']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                <form class="form-inline row" method="get" action="<?php echo e(url()->current()); ?>" role="search">
                    <div class="col-4 my-1">
                        <label>Search</label>
                        <input type="text" value="<?php echo e(request()->search); ?>" name="search" class="form-control input-lg" placeholder="search for..." />
                    </div>

                    <div class="col-4 my-1 mt-2">
                        <button type="submit" class="btn home-color text-white btn-sm mt-4">Search</button>
                    </div>
                </form>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isOga', request()->user('admin'))): ?>
                <div>
                    <a class="text-decoration-none text-dark float-end"
                        href="<?php echo e(route('admin.create')); ?>">
                        <i class="fas fa-circle-plus fa-2x"></i>
                    </a>
                </div>
                <?php endif; ?>

            <div class="table-responsive">
            <table class="table table-stripped table-bordered">
                <thead>
                    <tr class="sticky-top">
                        <th>S/N</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>

                        <th>Date Created</th>
                    </tr>
                </thead>
                <tbody>

                    <?php
                    $i = 0;
                    $offset = ($result->currentPage() - 1) * $result->perPage();
                    ?>

                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php
                    $i +=1;
                    $sn = $offset + $i;
                    ?>

                    <tr>
                        <td><?php echo e($sn); ?></td>
                        
                        <td><a class="text-home" href='<?php echo e(route('admin.create',['id'=>$items->id])); ?>'><?php echo e($items->name['firstname']); ?> <?php echo e($items->name['lastname']); ?></a>
                        </td>

                        <td><?php echo e($items->email); ?>

                        </td>

                        <td><span class="badge badge-pill bg-dark"><?php echo e($items->role); ?></span></td>

                        <td><span class="badge badge-pill bg-<?php echo e($items->active >=1 ? 'success' : 'danger'); ?>"><?php echo e($items->account_status); ?></span></td>

                        <td><?php echo e($items->created_at->toDayDateTimeString()); ?></td>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isOga', request()->user('admin'))): ?>
                        <td>
                            <div class="btn-group dropdown">
                                <button type="button" class="btn home-color text-white dropdown-toggle btn-sm" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  Manage
                                </button>
                                <div class="dropdown-menu">
                                  <a class="dropdown-item <?php echo e(($items->active >= 1) ? 'disabled' : null); ?>" href="<?php echo e(route('admin.reactivate', ['id'=>$items->id])); ?>"><i class="fa fa-play-circle text-success fa-fw"></i>Activate</a>
                                  
                                  <a class="dropdown-item pre-run <?php echo e(($items->active >= 1) ? null : 'disabled'); ?>" data-caption="Are you sure you want to deactivate this account?" href="<?php echo e(route('admin.deactivate', ['id'=>$items->id])); ?>"><i class="fa fa-circle-stop text-danger fa-fw"></i>Deactivate</a>
                                  
                                  <a class="dropdown-item bg-danger pre-run text-white text-decoration-none" href="<?php echo e(route('admin.delete', ['id'=>$items->id])); ?>" data-caption="Are you sure you want to delete this account? Note that this operation can not be undone."><i class="fa fa-address-book fa-fw"></i>Delete Account</a>

                                </div>
                            </div>
                        </td>
                        <?php endif; ?>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
            <hr />

            <?php echo e($result->links()); ?>



            <h3>Total: <?php echo e($result->total()); ?></h3>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\todo\resources\views/admin/admins.blade.php ENDPATH**/ ?>