<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="base_url" content="<?php echo e(URL::to('/')); ?>/">
        <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1.0 shrink-to-fit=no"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="theme-color" content="#A3031C">

        <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
        <?php echo $__env->yieldPushContent('styles'); ?><?php /**PATH C:\xampp\htdocs\todo\resources\views/components/meta-head.blade.php ENDPATH**/ ?>