<form action="<?php echo e(route('project.form.post')); ?>" id="form" data-bc="activity_trigger" method="post" role="form">

    <?php if(request()->filled('id')): ?>
        <input type="hidden" value="<?php echo e(request()->id); ?>" name="id" />
    <?php endif; ?>

    <div class="form-group mt-3">
        <label>Project Title</label>
        <input type='text' value="<?php echo e($activity->name ?? null); ?>" class="form-control-lg form-control" name="name"/>
    </div>

    <div class="form-group mt-3">
        <label>Deadline</label>
        <input type='date' value="<?php echo e($activity->deadline ?? request()->date); ?>" class="form-control-lg form-control" name="deadline"/>
    </div>

    <div class="form-group mt-3">
        <label>Description</label>
        <textarea class="form-control-lg form-control" style="border-radius:10px;" col="2" rows="2" name="description"><?php echo e($activity->description ?? null); ?></textarea>
    </div>


    <div class="form-group mt-3">
        <input type="submit" value="Submit" class="btn btn-primary w-100 btn-lg" />
    </div>
</form><?php /**PATH C:\xampp\htdocs\tasker\resources\views/snippet/project-form.blade.php ENDPATH**/ ?>