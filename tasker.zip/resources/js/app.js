import './bootstrap';
import '../css/app.css'
import '../sass/app.scss'
import '@fortawesome/fontawesome-free/css/all.css'