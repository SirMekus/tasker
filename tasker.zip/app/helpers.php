<?php
use Carbon\Carbon;

function carbon($date_time=null)
{
	return new Carbon($date_time);
}
?>